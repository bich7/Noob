
Astra Panel - STARVOS & INSAAN
---------------------------------

Run:
1. ./install.sh
2. source venv/bin/activate
3. python3 main.py

Default admin account: username: admin  password: admin123
