console.log('Astra Panel client loaded');
async function getJSON(url){ try{ let r=await fetch(url); if(r.ok) return await r.json(); return null; }catch(e){ return null; } }
