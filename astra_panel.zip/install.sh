#!/usr/bin/env bash
set -euo pipefail
PROJ_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$PROJ_DIR/venv"
PY=python3
echo "Creating virtual environment..."
$PY -m venv "$VENV"
source "$VENV/bin/activate"
pip install --upgrade pip setuptools wheel
pip install -r "$PROJ_DIR/requirements.txt"
mkdir -p "$PROJ_DIR/static/uploads"
echo "Initialization complete."
echo "Start the panel with:"
echo "source venv/bin/activate && python3 main.py"
