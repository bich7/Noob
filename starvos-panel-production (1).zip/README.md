# Starvos Panel — Production-ready bundle (starter)

This bundle provides a production-ready starter panel with multi-server support.
It includes a FastAPI backend that collects real system metrics (via psutil), controls services,
reads logs, provides a WebSocket terminal (local + remote via SSH), and supports multiple servers.

IMPORTANT: Features that control services, create users or run terminals require root privileges.
Run the backend on a trusted host. Consider using Docker and proper security measures in production.

See install.sh for a guided installer for Ubuntu/Debian systems. The installer can optionally install Cockpit binaries on the host.
