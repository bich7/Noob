// Starvos Panel front JS (production starter)
const API_BASE = '/api';

async function api(path, opts={}){
  try{
    const res = await fetch(API_BASE + path, opts);
    if(res.headers.get('content-type') && res.headers.get('content-type').includes('application/json')) return res.json();
    return res.text();
  }catch(e){ console.error('API error', e); return null; }
}

async function loadServers(){
  const sel = document.getElementById('serverSelect'); if(!sel) return;
  const list = await api('/servers');
  if(!list) return;
  sel.innerHTML = list.map(s=>`<option value="${s.id}">${s.name} (${s.host})</option>`).join('');
}

async function refreshLocalStats(){
  const s = await api('/stats/local');
  if(!s) return;
  document.getElementById('cpuVal') && (document.getElementById('cpuVal').textContent = Math.round(s.cpu_percent)+'%');
  document.getElementById('memVal') && (document.getElementById('memVal').textContent = Math.round(s.mem_used/1024/1024)+' MB / '+Math.round(s.mem_total/1024/1024)+' MB');
  document.getElementById('diskVal') && (document.getElementById('diskVal').textContent = Math.round(s.disk_used/1024/1024/1024)+' GB / '+Math.round(s.disk_total/1024/1024/1024)+' GB');
  document.getElementById('hostName') && (document.getElementById('hostName').textContent = s.hostname);
}

async function checkAlerts(){
  const res = await api('/alerts/check');
  if(!res) return;
  if(res.alerts && res.alerts.length){
    console.warn('Alerts:', res.alerts);
    // show small notification area if exists
    const a = document.getElementById('alertsArea'); if(a){ a.innerHTML = res.alerts.map(x=>`<div class="badge" style="margin-right:8px">${x.metric} ${x.value} >= ${x.threshold}</div>`).join(''); }
  }
}

document.addEventListener('DOMContentLoaded', function(){
  loadServers();
  refreshLocalStats();
  checkAlerts();
  // periodic refresh
  setInterval(refreshLocalStats, 5000);
  setInterval(checkAlerts, 10000);
});
