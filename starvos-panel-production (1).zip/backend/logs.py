import subprocess
from .servers import run_ssh_command, get_server

def tail_local(n=200):
    try:
        p = subprocess.run(['journalctl','-n',str(n),'--no-pager'], capture_output=True, text=True)
        return p.stdout
    except Exception:
        try:
            with open('/var/log/syslog','r') as f:
                lines = f.readlines()[-n:]
                return ''.join(lines)
        except Exception as e:
            return str(e)

def tail_remote(server_id, n=200):
    server = get_server(server_id)
    if not server: return ''
    cmd = f"journalctl -n {n} --no-pager 2>/dev/null || tail -n {n} /var/log/syslog"
    out, err = run_ssh_command(server, cmd)
    return out if out else err
