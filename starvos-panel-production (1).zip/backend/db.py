from sqlalchemy import MetaData, Table, Column, Integer, String, Boolean, create_engine, Float
import os

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./starvos.db')
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if 'sqlite' in DATABASE_URL else {})
metadata = MetaData()

users = Table('users', metadata,
    Column('id', Integer, primary_key=True),
    Column('username', String, unique=True, nullable=False),
    Column('full_name', String),
    Column('email', String),
    Column('hashed_password', String, nullable=False),
    Column('is_admin', Boolean, default=False)
)

servers = Table('servers', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String, nullable=False),
    Column('host', String, nullable=False),
    Column('port', Integer, default=22),
    Column('username', String),
    Column('auth_type', String, default='key'),
    Column('password', String),
    Column('key_path', String)
)

alerts = Table('alerts', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String),
    Column('metric', String),
    Column('threshold', Float)
)

def init_db():
    metadata.create_all(engine)
    conn = engine.connect()
    # create default admin if missing
    r = conn.execute(users.select().where(users.c.username == 'admin')).fetchone()
    if not r:
        from passlib.context import CryptContext
        pwd = CryptContext(schemes=['bcrypt'], deprecated='auto').hash('password')
        conn.execute(users.insert().values(username='admin', full_name='Administrator', email='admin@local', hashed_password=pwd, is_admin=True))
    conn.close()

if __name__ == '__main__':
    init_db()
    print('DB initialized')
