import asyncio, threading
from fastapi import WebSocket
from .servers import get_server, run_ssh_command
import paramiko, subprocess

async def proxy_local_shell(websocket: WebSocket):
    await websocket.accept()
    proc = await asyncio.create_subprocess_exec('/bin/bash', stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    async def read_out():
        try:
            while True:
                data = await proc.stdout.read(1024)
                if not data: break
                await websocket.send_text(data.decode(errors='ignore'))
        except Exception:
            pass
    reader_task = asyncio.create_task(read_out())
    try:
        while True:
            msg = await websocket.receive_text()
            if msg is None: break
            proc.stdin.write(msg.encode() + b'\n')
            await proc.stdin.drain()
    except Exception:
        pass
    try:
        proc.kill()
    except:
        pass
    reader_task.cancel()

def ssh_shell_thread(channel, websocket):
    try:
        while True:
            data = channel.recv(1024)
            if not data: break
            asyncio.run_coroutine_threadsafe(websocket.send_text(data.decode(errors='ignore')), asyncio.get_event_loop())
    except Exception:
        pass

async def proxy_remote_shell(websocket: WebSocket, server_id):
    await websocket.accept()
    server = get_server(server_id)
    if not server:
        await websocket.send_text('server not found'); await websocket.close(); return
    host=server['host']; port=server.get('port',22); username=server.get('username') or 'root'
    auth = server.get('auth_type','key')
    client = paramiko.SSHClient(); client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        if auth=='password':
            client.connect(host, port=port, username=username, password=server.get('password'))
        else:
            key_path = server.get('key_path') or '~/.ssh/id_rsa'
            client.connect(host, port=port, username=username, key_filename=key_path)
        chan = client.invoke_shell(term='xterm')
        t = threading.Thread(target=ssh_shell_thread, args=(chan, websocket), daemon=True)
        t.start()
        while True:
            msg = await websocket.receive_text()
            if msg is None: break
            chan.send(msg + '\n')
    except Exception as e:
        await websocket.send_text('ERROR: ' + str(e))
    try:
        client.close()
    except:
        pass
