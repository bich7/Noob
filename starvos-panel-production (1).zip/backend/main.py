import os, csv, io, time
from fastapi import FastAPI, HTTPException, WebSocket, Query, Body, Response
from fastapi.middleware.cors import CORSMiddleware
from .db import init_db, engine, users, servers, alerts
from .auth import authenticate_user, create_access_token, get_current_user
from .system import get_local_stats, get_remote_stats
from .services import control_local_service, list_local_services, control_remote_service
from .logs import tail_local, tail_remote
from .terminal_ws import proxy_local_shell, proxy_remote_shell
from .servers import list_servers, get_server
from .users import list_local_users, create_system_user
from sqlalchemy import select, insert
from dotenv import load_dotenv

load_dotenv()
init_db()

app = FastAPI(title='Starvos Panel Production')

app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

@app.post('/api/auth/login')
async def api_login(data: dict = Body(...)):
    username = data.get('username'); password = data.get('password')
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=400, detail='Invalid credentials')
    token = create_access_token({'sub': user.username})
    return {'access_token': token, 'token_type': 'bearer'}

@app.get('/api/me')
def api_me(authorization: str = None):
    user = get_current_user(authorization)
    return {'username': user.username, 'full_name': user.full_name, 'email': user.email, 'is_admin': user.is_admin}

@app.get('/api/servers')
def api_servers():
    return list_servers()

@app.post('/api/servers')
def api_add_server(data: dict = Body(...)):
    conn = engine.connect()
    conn.execute(insert(servers).values(name=data.get('name'), host=data.get('host'), port=data.get('port',22), username=data.get('username'), auth_type=data.get('auth_type','key'), password=data.get('password'), key_path=data.get('key_path')))
    conn.close()
    return {'ok': True}

@app.get('/api/stats/local')
def api_local_stats():
    return get_local_stats()

@app.get('/api/stats/remote/{server_id}')
def api_remote_stats(server_id: int):
    return get_remote_stats(server_id)

@app.get('/api/services/list')
def api_services_list():
    return {'services': list_local_services()}

@app.post('/api/service/local')
def api_service_local(data: dict = Body(...)):
    name = data.get('name'); action = data.get('action')
    code, out, err = control_local_service(name, action)
    return {'code': code, 'out': out, 'err': err}

@app.post('/api/service/remote/{server_id}')
def api_service_remote(server_id: int, data: dict = Body(...)):
    name = data.get('name'); action = data.get('action')
    code, out, err = control_remote_service(server_id, name, action)
    return {'code': code, 'out': out, 'err': err}

@app.get('/api/logs/local')
def api_logs_local(n: int = 200):
    return {'logs': tail_local(n)}

@app.get('/api/logs/remote/{server_id}')
def api_logs_remote(server_id: int, n: int = 200):
    return {'logs': tail_remote(server_id, n)}

@app.websocket('/ws/terminal/local')
async def ws_local_terminal(ws: WebSocket):
    await proxy_local_shell(ws)

@app.websocket('/ws/terminal/remote/{server_id}')
async def ws_remote_terminal(ws: WebSocket, server_id: int):
    await proxy_remote_shell(ws, server_id)

@app.get('/api/reports/export/csv')
def api_export_csv():
    stats = get_local_stats()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['metric','value'])
    for k,v in stats.items():
        writer.writerow([k,str(v)])
    return Response(content=output.getvalue(), media_type='text/csv')

@app.get('/api/alerts/check')
def api_check_alerts():
    # simple alert checks comparing env vars or DB alerts
    cpu_threshold = float(os.getenv('ALERT_CPU_PERCENT', '85'))
    disk_threshold = float(os.getenv('ALERT_DISK_PERCENT', '90'))
    mem_threshold = float(os.getenv('ALERT_MEM_PERCENT', '90'))
    s = get_local_stats()
    alerts = []
    if s['cpu_percent'] >= cpu_threshold:
        alerts.append({'metric':'cpu','value':s['cpu_percent'],'threshold':cpu_threshold})
    if s['disk_percent'] >= disk_threshold:
        alerts.append({'metric':'disk','value':s['disk_percent'],'threshold':disk_threshold})
    if s['mem_percent'] >= mem_threshold:
        alerts.append({'metric':'memory','value':s['mem_percent'],'threshold':mem_threshold})
    return {'alerts': alerts}
