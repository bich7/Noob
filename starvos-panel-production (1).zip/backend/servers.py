import paramiko, os
from .db import engine, servers
from sqlalchemy.sql import select as sql_select

def list_servers():
    conn = engine.connect()
    r = conn.execute(sql_select([servers])).fetchall()
    conn.close()
    return [dict(row) for row in r]

def get_server(sid):
    conn = engine.connect()
    r = conn.execute(sql_select([servers]).where(servers.c.id == sid)).fetchone()
    conn.close()
    return dict(r) if r else None

def run_ssh_command(server, cmd, timeout=20):
    host = server['host']; port = int(server.get('port',22)); username = server.get('username') or 'root'
    auth = server.get('auth_type','key')
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        if auth == 'password':
            client.connect(host, port=port, username=username, password=server.get('password'), timeout=10)
        else:
            key_path = server.get('key_path') or os.path.expanduser('~/.ssh/id_rsa')
            pkey = None
            try:
                pkey = paramiko.RSAKey.from_private_key_file(key_path)
            except Exception:
                try:
                    pkey = paramiko.Ed25519Key.from_private_key_file(key_path)
                except Exception:
                    pkey = None
            client.connect(host, port=port, username=username, pkey=pkey, timeout=10)
        stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
        out = stdout.read().decode(errors='ignore')
        err = stderr.read().decode(errors='ignore')
        client.close()
        return out, err
    except Exception as e:
        try: client.close()
        except: pass
        return '', str(e)
