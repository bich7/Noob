import subprocess, shlex
from .servers import run_ssh_command, get_server

def control_local_service(name, action):
    cmd = f"sudo systemctl {action} {name}"
    p = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr

def list_local_services():
    try:
        p = subprocess.run(['systemctl','list-units','--type=service','--no-pager','--no-legend'], capture_output=True, text=True)
        return p.stdout
    except Exception as e:
        return str(e)

def control_remote_service(server_id, name, action):
    server = get_server(server_id)
    if not server: return 1, '', 'server not found'
    cmd = f"sudo systemctl {action} {name}"
    out, err = run_ssh_command(server, cmd)
    return 0 if not err else 1, out, err
