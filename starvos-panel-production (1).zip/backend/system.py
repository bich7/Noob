import psutil, platform, os, time
from .servers import run_ssh_command, get_server

def get_local_stats():
    cpu = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    net = psutil.net_io_counters()
    return {
        'cpu_percent': cpu,
        'mem_total': mem.total,
        'mem_used': mem.used,
        'mem_percent': mem.percent,
        'disk_total': disk.total,
        'disk_used': disk.used,
        'disk_percent': disk.percent,
        'net_bytes_sent': net.bytes_sent,
        'net_bytes_recv': net.bytes_recv,
        'hostname': platform.node(),
        'os': platform.platform(),
        'uptime_seconds': int(time.time() - psutil.boot_time())
    }

def parse_remote(df):
    return df  # placeholder

def get_remote_stats(server_id):
    server = get_server(server_id)
    if not server: return None
    cmds = {
        'cpu': "top -bn1 | grep 'Cpu(s)' || top -bn1 | head -n1",
        'mem': "cat /proc/meminfo | head -n 5",
        'disk': "df -h / | tail -n1",
        'uptime': "cat /proc/uptime"
    }
    out_total = {}
    for k,c in cmds.items():
        out,err = run_ssh_command(server, c)
        out_total[k] = out or err
    return out_total
