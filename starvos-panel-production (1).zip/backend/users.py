import subprocess, shlex
from .db import engine, users as users_table
from sqlalchemy.sql import select as sql_select

def list_local_users():
    try:
        with open('/etc/passwd','r') as f:
            lines = f.readlines()
        users_list = []
        for l in lines:
            parts = l.split(':')
            users_list.append({'username':parts[0],'uid':parts[2],'home':parts[5].strip()})
        return users_list
    except Exception as e:
        return {'error': str(e)}

def create_system_user(username, password=None):
    try:
        subprocess.run(['sudo','useradd','-m', username], check=True)
        if password:
            subprocess.run(['bash','-lc', f"echo '{username}:{password}' | sudo chpasswd"], check=True)
        return True
    except Exception as e:
        return False, str(e)
