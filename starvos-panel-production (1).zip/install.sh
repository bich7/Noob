#!/usr/bin/env bash
set -e
echo "Starvos Panel Production installer (Ubuntu/Debian)"
if [ "$(id -u)" -ne 0 ]; then
  echo "Please run as root or with sudo."
  exit 1
fi
apt update
apt install -y python3 python3-venv python3-pip openssh-client sshpass curl git

# Optional: install Cockpit (binaries)
read -p "Install Cockpit on this host? (y/N): " INSTALL_COCKPIT
if [[ "$INSTALL_COCKPIT" =~ ^[Yy] ]]; then
  apt install -y cockpit
  systemctl enable --now cockpit.socket
  echo "Cockpit installed and running on port 9090"
fi

# Setup backend
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Initialize DB
python -c "from db import init_db; init_db()"
# Run backend
nohup .venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000 &>/dev/null &
echo "Backend started on http://0.0.0.0:8000"

echo "To serve frontend, use a webserver. For quick test:"
echo "  cd frontend && python3 -m http.server 8080"
echo "Or use docker-compose up -d to run nginx + backend."
