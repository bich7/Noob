from fastapi import FastAPI, Request
from pydantic import BaseModel
import uvicorn, os

app = FastAPI(title='Starvos Backend (demo)')

class VMCreate(BaseModel):
    panel_name: str
    username: str
    password: str = None
    ssh_key: str = None
    fqdn: str = None
    port: int = 22
    image: str = 'ubuntu-24.04'
    cpu: str = '2v'
    ram: str = '2g'
    disk: str = '20g'

@app.get('/')
def index():
    return {'ok': True, 'msg': 'Starvos backend running'}

@app.post('/api/v1/vms')
async def create_vm(payload: VMCreate):
    # Demo: accept request and write to file as record
    os.makedirs('backend/data', exist_ok=True)
    vm_id = 'vm-' + str(len(os.listdir('backend/data')) + 1)
    with open(f'backend/data/{vm_id}.json', 'w') as f:
        f.write(payload.json())
    return {'ok': True, 'vm_id': vm_id, 'received': payload.dict()}

if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8001, reload=False)
