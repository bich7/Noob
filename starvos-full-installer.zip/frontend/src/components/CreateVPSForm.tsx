import React, { useState } from 'react'
import axios from 'axios'

const API_URL = 'http://localhost:8001/api/v1/vms'

export default function CreateVPSForm(){
  const [form,setForm] = useState({panelName:'',username:'admin',password:'',ssh_key:'',fqdn:'',port:22,image:'ubuntu-24.04',cpu:'2v',ram:'2g',disk:'20g'})
  const [resp,setResp] = useState<any>(null)
  const [loading,setLoading] = useState(false)
  const change = (e:any)=> setForm({...form,[e.target.name]: e.target.value})
  const submit = async ()=>{
    if(!form.panelName || !form.username) return alert('panelName and username required')
    setLoading(true)
    try{
      const r = await axios.post(API_URL, {
        panel_name: form.panelName,
        username: form.username,
        password: form.password || undefined,
        ssh_key: form.ssh_key || undefined,
        fqdn: form.fqdn || undefined,
        port: Number(form.port)||22,
        image: form.image,
        cpu: form.cpu, ram: form.ram, disk: form.disk
      })
      setResp(r.data)
      alert('VM requested: '+r.data.vm_id)
    }catch(err){ console.error(err); alert('Error sending request') }
    setLoading(false)
  }
  return (
    <div style={{background:'rgba(255,255,255,0.03)',padding:16,borderRadius:12,maxWidth:760}}>
      <h2>Create VPS</h2>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
        <input name='panelName' value={form.panelName} onChange={change} placeholder='Panel Name' />
        <input name='fqdn' value={form.fqdn} onChange={change} placeholder='FQDN (optional)' />
        <input name='username' value={form.username} onChange={change} placeholder='Username' />
        <input name='password' value={form.password} onChange={change} placeholder='Password (optional)' />
        <input name='cpu' value={form.cpu} onChange={change} placeholder='CPU e.g. 2v' />
        <input name='ram' value={form.ram} onChange={change} placeholder='RAM e.g. 2g' />
        <input name='disk' value={form.disk} onChange={change} placeholder='Disk e.g. 20g' />
        <select name='image' value={form.image} onChange={change}>
          <option value='ubuntu-24.04'>Ubuntu 24.04</option>
          <option value='ubuntu-22.04'>Ubuntu 22.04</option>
          <option value='debian-12'>Debian 12</option>
        </select>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={submit} disabled={loading} style={{padding:'8px 16px',background:'#7c3aed',color:'#fff',borderRadius:8}}>{loading? 'Creating...':'Create VPS'}</button>
      </div>
      {resp && <pre style={{marginTop:12,background:'#000',color:'#0f0',padding:8}}>{JSON.stringify(resp,null,2)}</pre>}
    </div>
  )
}
