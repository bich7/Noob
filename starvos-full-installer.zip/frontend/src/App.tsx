import React from 'react'
import CreateVPSForm from './components/CreateVPSForm'
export default function App(){ return (
  <div style={{minHeight:'100vh',background:'#071029',color:'#fff',padding:24,fontFamily:'Inter, Arial'}}>
    <header style={{display:'flex',alignItems:'center',gap:12}}>
      <img src='/assets/logo.svg' alt='logo' style={{width:64}}/>
      <div>
        <h1 style={{margin:0}}>Starvos Panel</h1>
        <p style={{margin:0,opacity:0.7}}>Made by Starvos</p>
      </div>
    </header>
    <main style={{marginTop:24}}>
      <CreateVPSForm />
    </main>
  </div>
) }
