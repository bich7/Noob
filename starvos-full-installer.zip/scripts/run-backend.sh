#!/usr/bin/env bash
source ../venv/bin/activate 2>/dev/null || true
uvicorn backend.main:app --host 0.0.0.0 --port 8001
