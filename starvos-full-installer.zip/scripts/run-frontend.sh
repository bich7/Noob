#!/usr/bin/env bash
cd frontend
npm install --silent
npm run dev
