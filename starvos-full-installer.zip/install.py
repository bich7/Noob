#!/usr/bin/env python3
import os, getpass, subprocess

CONFIG_FILE = 'config.env'
SERVICE_NAME = 'starvos-panel'

def ask(prompt, default=None, secret=False):
    if default:
        prompt = f"{prompt} [{default}]: "
    else:
        prompt = f"{prompt}: "
    if secret:
        val = getpass.getpass(prompt)
    else:
        val = input(prompt).strip()
    return val or default

def write_config(panel_name, username, password, os_choice):
    with open(CONFIG_FILE, 'w') as f:
        f.write(f'PANEL_NAME={panel_name}\n')
        f.write(f'USERNAME={username}\n')
        f.write(f'PASSWORD={password}\n')
        f.write(f'OS={os_choice}\n')
    print('\n✅ Config written to', CONFIG_FILE)

def create_service():
    service = f"""
[Unit]
Description=Starvos Panel Service
After=network.target

[Service]
Type=simple
WorkingDirectory={os.getcwd()}
ExecStart=/usr/bin/python3 backend/main.py
Restart=always
User=root
EnvironmentFile={os.getcwd()}/config.env

[Install]
WantedBy=multi-user.target
"""
    path = f'/etc/systemd/system/{SERVICE_NAME}.service'
    try:
        with open(path, 'w') as f:
            f.write(service)
        subprocess.run(['systemctl', 'daemon-reload'])
        subprocess.run(['systemctl', 'enable', SERVICE_NAME])
        subprocess.run(['systemctl', 'start', SERVICE_NAME])
        print('🚀 Service started and enabled')
    except PermissionError:
        print('⚠️ Permission denied creating systemd service. Run script as root to enable service.')

def main():
    print('\n⭐ Made by Starvos ⭐\n')
    panel_name = ask('Panel name', 'starvos')
    username = ask('Username', 'admin')
    password = ask('Password', secret=True)
    os_choice = ask('OS (ubuntu-24.04 / ubuntu-22.04 / debian-12)', 'ubuntu-24.04')
    write_config(panel_name, username, password, os_choice)
    create_service()

if __name__ == '__main__':
    main()
