Starvos Panel — Full Installer Package
=====================================
What this package contains:
- install.py : terminal installer (asks Panel name, Username, Password, OS), writes config.env, creates systemd service
- backend/ : FastAPI app (main.py) that exposes /api/v1/vms endpoint and a simple UI health page
- frontend/ : Vite React TypeScript starter with Create VPS form integrated under "Made by Starvos"
- assets/ : logo svg and lottie placeholder to make the package substantial
- scripts/ : helper scripts (run-backend.sh, run-frontend.sh)

Quickstart (on Debian/Ubuntu VPS):
  1. unzip starvos-full-installer.zip -d starvos-panel
  2. cd starvos-panel
  3. python3 -m venv venv && source venv/bin/activate
  4. pip install -r backend/requirements.txt
  5. ./install.py     # answer prompts (panel name, username, password, OS)
  6. systemctl status starvos-panel  # service should be running
  7. To run frontend (optional): cd frontend && npm install && npm run dev

Note: This scaffold is for testing/demo. Review and secure before production.
