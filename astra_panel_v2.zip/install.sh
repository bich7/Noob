#!/usr/bin/env bash
set -euo pipefail
PY=python3
VENV=venv
$PY -m venv "$VENV"
source "$VENV/bin/activate"
pip install --upgrade pip
pip install -r requirements.txt
mkdir -p static/uploads
echo "Done. Run: source venv/bin/activate && python3 main.py"
