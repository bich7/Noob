import os, sqlite3, time, hashlib, threading, select, pty
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from flask_socketio import SocketIO, emit

BASE = os.path.dirname(__file__)
DB = os.path.join(BASE, "astra.db")
UPLOAD_FOLDER = os.path.join(BASE, "static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = os.environ.get("ASTRA_SECRET", "change_this_secret")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
socketio = SocketIO(app, async_mode="eventlet")

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

@app.before_request
def ensure_db():
    if not getattr(app, "db_initialized", False):
        if not os.path.exists(DB):
            conn = sqlite3.connect(DB)
            c = conn.cursor()
            c.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, email TEXT, role TEXT, avatar TEXT)")
            c.execute("CREATE TABLE containers (id INTEGER PRIMARY KEY, name TEXT, os_image TEXT, status TEXT, owner_id INTEGER)")
            c.execute("CREATE TABLE announcements (id INTEGER PRIMARY KEY, title TEXT, body TEXT, created_at INTEGER)")
            ph = hashlib.sha256(b"admin123").hexdigest()
            c.execute('INSERT INTO users (username,password,email,role,avatar) VALUES (?,?,?,?,?)', ("admin", ph, "admin@astra.local", "admin", "default"))
            c.execute('INSERT INTO users (username,password,email,role,avatar) VALUES (?,?,?,?,?)', ("demo", hashlib.sha256(b"demo123").hexdigest(), "demo@astra.local", "user", "default"))
            c.execute('INSERT INTO announcements (title,body,created_at) VALUES (?,?,?)', ("Welcome", "Welcome to Astra Panel powered by STARVOS & INSAAN", int(time.time())))
            conn.commit(); conn.close()
        app.db_initialized = True

def verify_password(stored, password):
    try:
        from werkzeug.security import check_password_hash
        if isinstance(stored, str) and ('pbkdf2:' in stored or stored.count('$')>1):
            return check_password_hash(stored, password)
    except Exception:
        pass
    return hashlib.sha256(password.encode()).hexdigest() == stored

def auth_ok(u,p):
    conn = get_db()
    r = conn.execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
    conn.close()
    if r and verify_password(r['password'], p):
        return True
    return False

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        u = request.form.get('username','').strip()
        p = request.form.get('password','')
        if auth_ok(u,p):
            session['user'] = u
            return redirect(url_for('dashboard'))
        flash('Invalid credentials','danger')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone()
    anns = conn.execute("SELECT * FROM announcements ORDER BY created_at DESC").fetchall()
    conn.close()
    return render_template('dashboard.html', user=user, announcements=anns)

@app.route('/containers')
def containers_page():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    rows = conn.execute("SELECT c.*, u.username as owner FROM containers c LEFT JOIN users u ON c.owner_id = u.id ORDER BY c.id DESC").fetchall()
    conn.close()
    return render_template('containers.html', containers=rows)

@app.route('/api/containers', methods=['GET','POST'])
def api_containers():
    if 'user' not in session:
        return jsonify({'error':'auth'}),401
    conn = get_db()
    if request.method=='POST':
        data = request.get_json() or {}
        name = data.get('name','ct-'+str(int(time.time())))
        os_img = data.get('os_image','ubuntu')
        userrow = conn.execute("SELECT id FROM users WHERE username=?", (session['user'],)).fetchone()
        owner = userrow['id'] if userrow else None
        conn.execute("INSERT INTO containers (name,os_image,status,owner_id) VALUES (?,?,?,?)", (name, os_img, 'created', owner))
        conn.commit()
    rows = conn.execute("SELECT c.*, u.username as owner FROM containers c LEFT JOIN users u ON c.owner_id = u.id ORDER BY c.id DESC").fetchall()
    items = [dict(r) for r in rows]
    conn.close()
    return jsonify({'containers':items})

@app.route('/api/container/<int:cid>/<action>', methods=['POST'])
def container_action(cid, action):
    if 'user' not in session:
        return jsonify({'error':'auth'}),401
    if action not in ('start','stop','restart','remove'):
        return jsonify({'error':'invalid'}),400
    conn = get_db()
    if action=='remove':
        conn.execute("DELETE FROM containers WHERE id=?", (cid,))
    else:
        status = 'running' if action=='start' else ('exited' if action=='stop' else 'restarting')
        conn.execute("UPDATE containers SET status=? WHERE id=?", (status, cid))
    conn.commit(); conn.close()
    return jsonify({'ok':True})

@app.route('/settings', methods=['GET','POST'])
def settings():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone()
    if request.method=='POST':
        email = request.form.get('email','').strip()
        pw = request.form.get('password','').strip()
        if pw:
            conn.execute("UPDATE users SET password=? WHERE username=?", (hashlib.sha256(pw.encode()).hexdigest(), session['user']))
        conn.execute("UPDATE users SET email=? WHERE username=?", (email, session['user']))
        conn.commit()
        flash('Updated','success')
        user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone()
    conn.close()
    return render_template('settings.html', user=user)

@app.route('/uploads/<path:filename>')
def uploads(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__=='__main__':
    print('\n*** STARTING ASTRA PANEL V2 - STARVOS & INSAAN ***\n')
    socketio.run(app, host='0.0.0.0', port=8000, debug=True)
