Astra Panel v2 - run install.sh then start main.py
Default admin/admin123
