
import os, sqlite3, subprocess, json, psutil, threading, select, pty, time
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(__file__)
DB = os.path.join(BASE, "panel.db")

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config['SECRET_KEY'] = os.environ.get('ASTRA_SECRET','change_me_now')
socketio = SocketIO(app, async_mode='eventlet')

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not os.path.exists(DB):
        conn = get_db()
        c = conn.cursor()
        c.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, email TEXT, role TEXT DEFAULT 'user', active INTEGER DEFAULT 1, last_login TEXT)")
        c.execute("CREATE TABLE announcements (id INTEGER PRIMARY KEY, title TEXT, message TEXT, image TEXT, start_at TEXT, end_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        c.execute("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)")
        pw = generate_password_hash("password123")
        c.execute("INSERT INTO users (username,password_hash,email,role,active) VALUES (?,?,?,?,1)", ("admin", pw, "admin@astra.local", "admin"))
        conn.commit()
        conn.close()

init_db()

def check_login(u,p):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE username=? AND active=1",(u,)).fetchone()
    conn.close()
    if row:
        return check_password_hash(row["password_hash"], p)
    return False

def get_user(u):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE username=?",(u,)).fetchone()
    conn.close()
    return row

@app.route("/")
def index():
    if "user" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u = request.form.get("username","").strip()
        p = request.form.get("password","")
        if check_login(u,p):
            session["user"]=u
            conn = get_db()
            conn.execute("UPDATE users SET last_login = datetime('now') WHERE username=?",(u,))
            conn.commit(); conn.close()
            return redirect(url_for("dashboard"))
        flash("Invalid credentials","danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html", user=session.get("user"))

@app.route("/api/metrics")
def api_metrics():
    if "user" not in session: return jsonify({"error":"auth"}),401
    cpu = psutil.cpu_percent(interval=0.1, percpu=True)
    mem = psutil.virtual_memory()._asdict()
    disk = psutil.disk_usage("/")._asdict()
    net = psutil.net_io_counters(pernic=True)
    net_simple = {k:{"sent":v.bytes_sent,"recv":v.bytes_recv} for k,v in net.items()}
    return jsonify({"cpu":cpu,"mem":mem,"disk":disk,"net":net_simple})

@app.route("/api/logs")
def api_logs():
    if "user" not in session: return jsonify({"error":"auth"}),401
    try:
        p = subprocess.run(["journalctl","-n","400","-o","short"], capture_output=True, text=True, check=False)
        out = p.stdout if p.stdout else p.stderr
    except Exception:
        try:
            with open("/var/log/syslog","r") as f:
                out = "".join(f.readlines()[-400:])
        except Exception:
            out = "No logs available"
    return jsonify({"logs":out})

@app.route("/api/services")
def api_services():
    if "user" not in session: return jsonify({"error":"auth"}),401
    try:
        p = subprocess.run(["systemctl","list-units","--type=service","--no-legend","--all"], capture_output=True, text=True, check=False)
        lines = p.stdout.splitlines()
        services=[]
        for L in lines:
            parts=L.split()
            if len(parts)>=5:
                services.append({"name":parts[0],"load":parts[1],"active":parts[2],"sub":parts[3],"desc":" ".join(parts[4:])})
    except Exception as e:
        services=[{"error":"systemctl not available","detail":str(e)}]
    return jsonify({"services":services})

@app.route("/api/service/<name>/<action>", methods=["POST"])
def api_service_action(name,action):
    if "user" not in session: return jsonify({"error":"auth"}),401
    if action not in ("start","stop","restart","enable","disable","status"):
        return jsonify({"error":"invalid"}),400
    try:
        p = subprocess.run(["sudo","systemctl",action,name], capture_output=True, text=True, check=False)
        return jsonify({"out":p.stdout,"err":p.stderr,"rc":p.returncode})
    except Exception as e:
        return jsonify({"error":str(e)}),500

@app.route("/api/containers")
def api_containers():
    if "user" not in session: return jsonify({"error":"auth"}),401
    try:
        p = subprocess.run(["docker","ps","-a","--format","{{json .}}"], capture_output=True, text=True, check=False)
        lines = p.stdout.strip().splitlines()
        items=[]
        for L in lines:
            try:
                items.append(json.loads(L))
            except:
                items.append({"raw":L})
    except Exception as e:
        items=[{"error":"docker not available","detail":str(e)}]
    return jsonify({"containers":items})

@app.route("/api/container/<cid>/<action>", methods=["POST"])
def api_container_action(cid,action):
    if "user" not in session: return jsonify({"error":"auth"}),401
    if action not in ("start","stop","restart","remove"):
        return jsonify({"error":"invalid"}),400
    try:
        p = subprocess.run(["docker",action,cid], capture_output=True, text=True, check=False)
        return jsonify({"out":p.stdout,"err":p.stderr,"rc":p.returncode})
    except Exception as e:
        return jsonify({"error":str(e)}),500

@app.route("/api/announcements", methods=["GET","POST"])
def api_announcements():
    if "user" not in session: return jsonify({"error":"auth"}),401
    conn = get_db()
    if request.method=="POST":
        data=request.json or {}
        conn.execute("INSERT INTO announcements (title,message,image,start_at,end_at) VALUES (?,?,?,?,?)", (data.get("title"), data.get("message"), data.get("image"), None, None))
        conn.commit()
        return jsonify({"ok":True})
    rows = conn.execute("SELECT * FROM announcements ORDER BY created_at DESC").fetchall()
    return jsonify({"announcements":[dict(r) for r in rows]})

@app.route("/api/users", methods=["GET","POST"])
def api_users():
    if "user" not in session: return jsonify({"error":"auth"}),401
    me = get_user(session.get("user"))
    if not me or me["role"]!="admin": return jsonify({"error":"forbidden"}),403
    conn = get_db()
    if request.method=="POST":
        d=request.json or {}
        pw = generate_password_hash(d.get("password","password123"))
        try:
            conn.execute("INSERT INTO users (username,password_hash,email,role,active) VALUES (?,?,?,?,1)", (d.get("username"), pw, d.get("email",""), d.get("role","user")))
            conn.commit()
            return jsonify({"ok":True})
        except Exception as e:
            return jsonify({"error":str(e)}),400
    rows = conn.execute("SELECT id,username,email,role,active,last_login FROM users").fetchall()
    return jsonify({"users":[dict(r) for r in rows]})

@app.route("/api/settings/hostname", methods=["POST"])
def api_hostname():
    if "user" not in session: return jsonify({"error":"auth"}),401
    me=get_user(session.get("user"))
    if not me or me["role"]!="admin": return jsonify({"error":"forbidden"}),403
    new = request.json.get("hostname")
    try:
        p = subprocess.run(["sudo","hostnamectl","set-hostname", new], capture_output=True, text=True, check=False)
        return jsonify({"out":p.stdout,"err":p.stderr,"rc":p.returncode})
    except Exception as e:
        return jsonify({"error":str(e)}),500

@socketio.on("connect", namespace="/term")
def term_connect():
    emit("term_output", {"data":"Connected to Astra Terminal\r\n"})

@socketio.on("start_terminal", namespace="/term")
def start_terminal(data):
    cols = int(data.get("cols",80))
    rows = int(data.get("rows",24))
    pid, fd = pty.fork()
    if pid==0:
        shell = os.environ.get("SHELL","/bin/bash")
        os.execvp(shell, [shell])
    else:
        def reader():
            maxr = 1024
            while True:
                try:
                    r,_,_ = select.select([fd],[],[],0.1)
                    if fd in r:
                        out = os.read(fd, maxr).decode(errors="ignore")
                        socketio.emit("term_output", {"data":out}, namespace="/term")
                except OSError:
                    break
        threading.Thread(target=reader, daemon=True).start()
        socketio.server.environ.get(request.sid, {})["pty_fd"] = fd

@socketio.on("term_input", namespace="/term")
def term_input(data):
    fd = socketio.server.environ.get(request.sid, {}).get("pty_fd")
    if not fd: return
    try:
        os.write(fd, data.get("input","").encode())
    except Exception:
        pass

@app.route("/<page>")
def pages(page):
    if "user" not in session and page!="login":
        return redirect(url_for("login"))
    allowed = ("dashboard","services","containers","logs","terminal","admin","settings","announcements","users")
    if page not in allowed:
        return "Not found",404
    return render_template(f"{page}.html", user=session.get("user"))

if __name__=="__main__":
    socketio.run(app, host="0.0.0.0", port=8000, debug=True)
