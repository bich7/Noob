#!/bin/bash
set -e
echo "Installing Astra Panel prerequisites..."
if [ -x "$(command -v apt)" ]; then
  sudo apt update
  sudo apt install -y python3 python3-venv python3-pip docker.io docker-compose
  sudo systemctl enable --now docker
fi
python3 -m pip install --upgrade pip
pip3 install -r requirements.txt
echo "Done. You can run: python3 main.py"
