Astra Panel - Full package. Default admin: admin / password123
See README for details.