
#!/usr/bin/env bash
set -euo pipefail
PROJ_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$PROJ_DIR/venv"
PYBIN="$(command -v python3 || true)"
if [ -z "$PYBIN" ]; then
  echo "Python3 not found. Install Python 3.8+ and rerun."
  exit 1
fi
echo "Using python: $PYBIN"
if [ ! -d "$VENV_DIR" ]; then
  "$PYBIN" -m venv "$VENV_DIR"
fi
source "$VENV_DIR/bin/activate"
pip install --upgrade pip setuptools wheel
if [ -f "$PROJ_DIR/requirements.txt" ]; then
  pip install -r "$PROJ_DIR/requirements.txt"
fi
mkdir -p "$PROJ_DIR/static/uploads"
if [ ! -f "$PROJ_DIR/astra.db" ]; then
  python3 - <<'PY'
import sqlite3, os
db='astra.db'
conn=sqlite3.connect(db)
c=conn.cursor()
c.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, email TEXT, role TEXT, avatar TEXT)")
c.execute("CREATE TABLE containers (id INTEGER PRIMARY KEY, name TEXT, os_image TEXT, status TEXT, owner_id INTEGER)")
from werkzeug.security import generate_password_hash
c.execute("INSERT INTO users (username,password_hash,email,role,avatar) VALUES (?,?,?,?,?)", ("admin", generate_password_hash("admin123"), "admin@astra.local", "admin", "default"))
conn.commit(); conn.close()
print('Created astra.db with default admin/admin123')
PY
fi
cat > run_panel.sh <<'RUN'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source venv/bin/activate
python3 main.py
RUN
chmod +x run_panel.sh
echo "Installation finished. Run ./run_panel.sh to start the panel."
