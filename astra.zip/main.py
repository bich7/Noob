
import os, sqlite3, time, random, threading, select, pty
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_socketio import SocketIO, emit

BASE = os.path.dirname(__file__)
DB = os.path.join(BASE, "astra.db")
UPLOAD_FOLDER = os.path.join(BASE, "static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config['SECRET_KEY'] = os.environ.get('ASTRA_SECRET','change_this_secret')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
socketio = SocketIO(app, async_mode='eventlet')

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

@app.before_first_request
def init_db():
    if not os.path.exists(DB):
        conn = get_db()
        c = conn.cursor()
        c.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, email TEXT, role TEXT, avatar TEXT)")
        c.execute("CREATE TABLE containers (id INTEGER PRIMARY KEY, name TEXT, os_image TEXT, status TEXT, owner_id INTEGER)")
        admin_pw = generate_password_hash('admin123')
        c.execute("INSERT INTO users (username,password_hash,email,role,avatar) VALUES (?,?,?,?,?)", ('admin', admin_pw, 'admin@astra.local','admin','default'))
        conn.commit()
        conn.close()

def auth_ok(u,p):
    conn = get_db()
    r = conn.execute("SELECT * FROM users WHERE username=?",(u,)).fetchone()
    conn.close()
    if r and check_password_hash(r['password_hash'], p):
        return True
    return False

@app.route('/')
def root():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        u = request.form.get('username','').strip()
        p = request.form.get('password','')
        file = request.files.get('avatar')
        if file and file.filename:
            filename = secure_filename(file.filename)
            savep = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(savep)
            conn = get_db(); row = conn.execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
            if row:
                conn.execute("UPDATE users SET avatar=? WHERE username=?", (filename, u)); conn.commit()
            conn.close()
            session['avatar_temp'] = filename
        if auth_ok(u,p):
            session['user'] = u
            if session.get('avatar_temp'):
                conn = get_db(); conn.execute("UPDATE users SET avatar=? WHERE username=?", (session['avatar_temp'], u)); conn.commit(); conn.close(); session.pop('avatar_temp', None)
            return redirect(url_for('dashboard'))
        flash('Invalid credentials','danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn = get_db(); user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone(); conn.close()
    return render_template('dashboard.html', user=user)

@app.route('/settings', methods=['GET','POST'])
def settings():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone()
    if request.method=='POST':
        email = request.form.get('email','').strip()
        avatar_choice = request.form.get('avatar_choice','default')
        pw = request.form.get('password','').strip()
        if 'avatar_file' in request.files and request.files['avatar_file'].filename:
            f = request.files['avatar_file']
            fname = secure_filename(f.filename); f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
            avatar_choice = fname
        if pw:
            conn.execute("UPDATE users SET password_hash=? WHERE username=?", (generate_password_hash(pw), session['user']))
        conn.execute("UPDATE users SET email=?, avatar=? WHERE username=?", (email, avatar_choice, session['user']))
        conn.commit()
        flash('Profile updated','success')
        user = conn.execute("SELECT * FROM users WHERE username=?", (session['user'],)).fetchone()
    conn.close()
    return render_template('settings.html', user=user)

@app.route('/api/metrics')
def metrics():
    if 'user' not in session:
        return jsonify({'error':'auth'}),401
    cpu = [round(random.uniform(1,90),2) for _ in range(12)]
    mem = {'total':16384,'used':round(random.uniform(256,12000),2)}
    disk = {'total':512000,'used':round(random.uniform(10000,300000),2)}
    return jsonify({'cpu':cpu,'mem':mem,'disk':disk,'time':int(time.time())})

@app.route('/api/containers', methods=['GET','POST'])
def api_containers():
    if 'user' not in session:
        return jsonify({'error':'auth'}),401
    conn = get_db()
    if request.method=='POST':
        data = request.json or {}
        name = data.get('name','ct-'+str(int(time.time())))
        os_img = data.get('os_image','ubuntu')
        userrow = conn.execute("SELECT id FROM users WHERE username=?", (session['user'],)).fetchone()
        owner = userrow['id'] if userrow else None
        conn.execute("INSERT INTO containers (name,os_image,status,owner_id) VALUES (?,?,?,?)", (name, os_img, 'created', owner))
        conn.commit()
    rows = conn.execute("SELECT c.*, u.username as owner FROM containers c LEFT JOIN users u ON c.owner_id = u.id ORDER BY c.id DESC").fetchall()
    items = [dict(r) for r in rows]
    conn.close()
    return jsonify({'containers':items})

@app.route('/api/container/<int:cid>/<action>', methods=['POST'])
def container_action(cid, action):
    if 'user' not in session:
        return jsonify({'error':'auth'}),401
    if action not in ('start','stop','restart','remove'):
        return jsonify({'error':'invalid'}),400
    conn = get_db()
    if action=='remove':
        conn.execute("DELETE FROM containers WHERE id=?", (cid,))
    else:
        status = 'running' if action=='start' else ('exited' if action=='stop' else 'restarting')
        conn.execute("UPDATE containers SET status=? WHERE id=?", (status, cid))
    conn.commit(); conn.close()
    return jsonify({'ok':True})

@app.route('/uploads/<path:filename>')
def uploads(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@socketio.on('connect', namespace='/term')
def term_connect():
    banner = \"\"\"  _____ _  _    _    _____  __     ___  \n / ___/| || |  / \\  |_   _| \\ \\   / (_) \n \\___ \\| || |_|  |    | |    \\ \\ / /| | \n  ___) |__   _|  |    | |     \\ V / | | \n |____/   |_| |_|     |_|      \\_/  |_| \n\n  _____ _____ _   _    _    _   _ _   _ \n |_   _| ____| \\ | |  / \\  | \\ | | \\ | |\n   | | |  _| |  \\| | / _ \\ |  \\| |  \\| |\n   | | | |___| |\\  |/ ___ \\| |\\  | |\\  |\n   |_| |_____|_| \\_/_/   \\_\\_| \\_|_| \\_|\n\n Powered by STARVOS & INSAAN\\n\\n\"\"\"\n    emit('term_output', {'data': banner})\n\n@socketio.on('start_terminal', namespace='/term')\ndef start_terminal(data):\n    cols = int(data.get('cols',80)); rows = int(data.get('rows',24))\n    pid, fd = pty.fork()\n    if pid==0:\n        shell = os.environ.get('SHELL','/bin/bash')\n        os.execvp(shell, [shell])\n    else:\n        def reader():\n            maxr = 1024\n            while True:\n                try:\n                    r,_,_ = select.select([fd],[],[],0.1)\n                    if fd in r:\n                        out = os.read(fd, maxr).decode(errors='ignore')\n                        socketio.emit('term_output', {'data':out}, namespace='/term')\n                except OSError:\n                    break\n        threading.Thread(target=reader, daemon=True).start()\n        socketio.server.environ.get(request.sid, {})['pty_fd'] = fd\n\n@socketio.on('term_input', namespace='/term')\ndef term_input(data):\n    fd = socketio.server.environ.get(request.sid, {}).get('pty_fd')\n    if not fd: return\n    try:\n        os.write(fd, data.get('input','').encode())\n    except Exception:\n        pass\n\nif __name__=='__main__':\n    print('\\n*** STARTING ASTRA PANEL ***\\n')\n    socketio.run(app, host='0.0.0.0', port=8000, debug=True)\n