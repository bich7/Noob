from fastapi import FastAPI
from .routers import auth, images, vms, system, admin
app = FastAPI(title='Starvos Panel')
app.include_router(auth.router, prefix='/api/v1/auth')
app.include_router(images.router, prefix='/api/v1/images')
app.include_router(vms.router, prefix='/api/v1/vms')
app.include_router(system.router, prefix='/api/v1/system')
app.include_router(admin.router, prefix='/api/v1/admin')
