// main client behaviour - snow loader
(function(){var s=document.createElement('script');s.src='/static/js/snow.js';document.head.appendChild(s);})();