# auth helpers

def is_admin(user_row):
    return user_row and user_row.get('role')=='admin'
