# Astra Panel Pro
Run with python3 main.py and open /login
