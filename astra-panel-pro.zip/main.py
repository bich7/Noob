
import os, sqlite3, subprocess, json, threading, select, pty, time
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_socketio import SocketIO, emit
BASE = os.path.dirname(__file__)
DB = os.path.join(BASE, "panel.db")
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config['SECRET_KEY'] = os.environ.get('ASTRA_SECRET', 'change_this_secret_for_prod')
socketio = SocketIO(app, async_mode='eventlet')
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn
def init_db():
    if not os.path.exists(DB):
        conn = get_db()
        c = conn.cursor()
        c.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, role TEXT, active INTEGER DEFAULT 1)")
        c.execute("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)")
        pw = generate_password_hash("admin123")
        c.execute("INSERT INTO users (username,password_hash,role,active) VALUES (?,?,?,1)", ("admin", pw, "admin"))
        conn.commit()
        conn.close()
init_db()
def check_login(u,p):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE username=? AND active=1",(u,)).fetchone()
    conn.close()
    if row:
        return check_password_hash(row["password_hash"], p)
    return False
@app.route("/")
def root():
    return redirect(url_for("login"))
@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username","").strip()
        p = request.form.get("password","")
        if check_login(u,p):
            session["user"]=u
            return redirect(url_for("dashboard"))
        flash("Invalid credentials","danger")
    return render_template("login.html")
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html", user=session.get("user"))
@app.route("/api/metrics")
def api_metrics():
    if "user" not in session:
        return jsonify({"error":"auth"}),401
    import random, time
    cpu = [round(random.uniform(2,80),2) for _ in range(12)]
    mem = {"total":16384, "used": round(random.uniform(1024,8000),2)}
    disk = {"total":256000, "used": round(random.uniform(10000,120000),2)}
    net = {"eth0":{"sent":random.randint(1000,100000),"recv":random.randint(1000,100000)}}
    return jsonify({"cpu":cpu,"mem":mem,"disk":disk,"net":net,"time":int(time.time())})
@app.route("/api/containers")
def api_containers():
    if "user" not in session:
        return jsonify({"error":"auth"}),401
    items = [
        {"id":"a1b2c3","name":"web","image":"nginx:latest","status":"running"},
        {"id":"d4e5f6","name":"db","image":"mysql:8.0","status":"exited"},
    ]
    return jsonify({"containers":items})
@socketio.on("connect", namespace="/term")
def term_connect():
    emit("term_output", {"data":"Connected to Astra Terminal\r\n"})
@socketio.on("start_terminal", namespace="/term")
def start_terminal(data):
    cols = int(data.get("cols",80))
    rows = int(data.get("rows",24))
    pid, fd = pty.fork()
    if pid==0:
        shell = os.environ.get("SHELL","/bin/bash")
        os.execvp(shell, [shell])
    else:
        def reader():
            maxr = 1024
            while True:
                try:
                    r,_,_ = select.select([fd],[],[],0.1)
                    if fd in r:
                        out = os.read(fd, maxr).decode(errors="ignore")
                        socketio.emit("term_output", {"data":out}, namespace="/term")
                except OSError:
                    break
        threading.Thread(target=reader, daemon=True).start()
        socketio.server.environ.get(request.sid, {})["pty_fd"] = fd
@socketio.on("term_input", namespace="/term")
def term_input(data):
    fd = socketio.server.environ.get(request.sid, {}).get("pty_fd")
    if not fd: return
    try:
        os.write(fd, data.get("input","").encode())
    except Exception:
        pass
if __name__=="__main__":
    socketio.run(app, host="0.0.0.0", port=8000, debug=True)
