import os, sqlite3, time, hashlib
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, flash, jsonify
from flask_socketio import SocketIO, emit

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config['SECRET_KEY'] = os.environ.get('ASTRA_SECRET','change_me')
socketio = SocketIO(app, async_mode='eventlet')

DB='astra.db'
UPLOAD='static/uploads'
os.makedirs(UPLOAD, exist_ok=True)

def init_db():
    if not os.path.exists(DB):
        conn=sqlite3.connect(DB)
        c=conn.cursor()
        c.execute('CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, email TEXT, role TEXT, avatar TEXT)')
        c.execute('CREATE TABLE containers (id INTEGER PRIMARY KEY, name TEXT, os_image TEXT, status TEXT, owner_id INTEGER)')
        c.execute('CREATE TABLE announcements (id INTEGER PRIMARY KEY, title TEXT, body TEXT, created_at INTEGER)')
        pw=os.environ.get('ASTRA_ADMIN_PW','starvos123')
        h=hashlib.sha256(pw.encode()).hexdigest()
        c.execute('INSERT INTO users (username,password,email,role,avatar) VALUES (?,?,?,?,?)', ('admin', h, 'admin@astra.local','admin','default'))
        c.execute('INSERT INTO announcements (title,body,created_at) VALUES (?,?,?)', ('Welcome','Welcome to Astra Panel powered by STARVOS & INSAAN', int(time.time())))
        conn.commit(); conn.close()

def check_auth(u,p):
    conn=sqlite3.connect(DB); c=conn.cursor()
    c.execute('SELECT password FROM users WHERE username=?',(u,))
    r=c.fetchone(); conn.close()
    if not r: return False
    return hashlib.sha256(p.encode()).hexdigest()==r[0]

@app.before_first_request
def before():
    init_db()

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username'); p=request.form.get('password')
        if check_auth(u,p):
            session['user']=u
            return redirect(url_for('dashboard'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    conn=sqlite3.connect(DB); c=conn.cursor()
    c.execute('SELECT title,body FROM announcements ORDER BY created_at DESC')
    anns=c.fetchall(); conn.close()
    return render_template('dashboard.html', announcements=anns, user={'username':session.get('user')})

@app.route('/api/containers', methods=['GET','POST'])
def api_containers():
    if 'user' not in session: return jsonify({'error':'auth'}),401
    conn=sqlite3.connect(DB); c=conn.cursor()
    if request.method=='POST':
        data=request.get_json() or {}
        name=data.get('name') or 'ct-'+str(int(time.time()))
        img=data.get('os_image') or 'ubuntu'
        c.execute('INSERT INTO containers (name,os_image,status,owner_id) VALUES (?,?,?,?)',(name,img,'created',1))
        conn.commit()
    c.execute('SELECT * FROM containers')
    rows=[dict(id=r[0],name=r[1],os_image=r[2],status=r[3]) for r in c.fetchall()]
    conn.close()
    return jsonify({'containers':rows})

@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory('static', path)

@socketio.on('connect', namespace='/term')
def on_connect():
    emit('term_output', {'data':'STARVOS & INSAAN Terminal\n'})

@socketio.on('term_input', namespace='/term')
def on_input(data):
    emit('term_output', {'data': '> ' + data.get('input','')}, namespace='/term')

if __name__=='__main__':
    socketio.run(app, host='0.0.0.0', port=8000, debug=True)
